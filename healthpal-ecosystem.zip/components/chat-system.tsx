"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, User, Stethoscope, Phone, Video, Paperclip } from "lucide-react"

interface Message {
  id: string
  senderId: string
  senderName: string
  senderType: "patient" | "doctor"
  content: string
  timestamp: Date
  type: "text" | "image" | "file"
  status: "sent" | "delivered" | "read"
}

interface ChatSystemProps {
  currentUserId: string
  currentUserType: "patient" | "doctor"
  recipientId: string
  recipientName: string
  recipientType: "patient" | "doctor"
}

export function ChatSystem({
  currentUserId,
  currentUserType,
  recipientId,
  recipientName,
  recipientType,
}: ChatSystemProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      senderId: recipientId,
      senderName: recipientName,
      senderType: recipientType,
      content: "Hello! How are you feeling today?",
      timestamp: new Date(Date.now() - 3600000),
      type: "text",
      status: "read",
    },
    {
      id: "2",
      senderId: currentUserId,
      senderName: "You",
      senderType: currentUserType,
      content: "I'm feeling much better after taking the prescribed medication. Thank you!",
      timestamp: new Date(Date.now() - 1800000),
      type: "text",
      status: "read",
    },
  ])

  const [newMessage, setNewMessage] = useState("")
  const [isOnline, setIsOnline] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = (e?: React.FormEvent) => {
    e?.preventDefault()
    if (!newMessage.trim()) return

    const message: Message = {
      id: Date.now().toString(),
      senderId: currentUserId,
      senderName: "You",
      senderType: currentUserType,
      content: newMessage,
      timestamp: new Date(),
      type: "text",
      status: "sent",
    }

    setMessages((prev) => [...prev, message])
    setNewMessage("")

    // Simulate message delivery and read status
    setTimeout(() => {
      setMessages((prev) => prev.map((msg) => (msg.id === message.id ? { ...msg, status: "delivered" } : msg)))
    }, 1000)

    setTimeout(() => {
      setMessages((prev) => prev.map((msg) => (msg.id === message.id ? { ...msg, status: "read" } : msg)))
    }, 3000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "sent":
        return "✓"
      case "delivered":
        return "✓✓"
      case "read":
        return "✓✓"
      default:
        return ""
    }
  }

  return (
    <div className="h-full flex flex-col bg-white rounded-lg border border-gray-200">
      {/* Header */}
      <div className="border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center">
              {recipientType === "doctor" ? (
                <Stethoscope className="w-5 h-5 text-white" />
              ) : (
                <User className="w-5 h-5 text-white" />
              )}
            </div>
            <div>
              <h3 className="text-lg font-semibold">{recipientName}</h3>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${isOnline ? "bg-green-500" : "bg-gray-400"}`} />
                <span className="text-sm text-gray-500">{isOnline ? "Online" : "Last seen 2 hours ago"}</span>
              </div>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-600 bg-transparent">
              <Phone className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-600 bg-transparent">
              <Video className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.senderId === currentUserId ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    message.senderId === currentUserId ? "bg-emerald-500 text-white" : "bg-gray-100 text-gray-900"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs opacity-70">{formatTime(message.timestamp)}</span>
                    {message.senderId === currentUserId && (
                      <span className={`text-xs ml-2 ${message.status === "read" ? "text-blue-200" : "opacity-70"}`}>
                        {getStatusIcon(message.status)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>

      {/* Input */}
      <div className="border-t p-4">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <Button type="button" size="sm" variant="outline" className="border-gray-300 flex-shrink-0 bg-transparent">
            <Paperclip className="w-4 h-4" />
          </Button>
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
          />
          <Button
            type="submit"
            disabled={!newMessage.trim()}
            className="bg-emerald-500 hover:bg-emerald-600 text-white flex-shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  )
}
