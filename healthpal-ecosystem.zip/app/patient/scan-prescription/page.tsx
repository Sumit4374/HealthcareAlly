"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Scan, Upload, Camera, FileText, Plus } from "lucide-react"
import { PatientSidebar } from "@/components/patient-sidebar"

export default function ScanPrescriptionPage() {
  const [scannedData, setScannedData] = useState<any>(null)
  const [isScanning, setIsScanning] = useState(false)

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setIsScanning(true)
      // Simulate AI processing
      setTimeout(() => {
        setScannedData({
          medications: [
            {
              name: "Amoxicillin 500mg",
              dosage: "1 tablet",
              frequency: "3 times daily",
              duration: "7 days",
              instructions: "Take with food",
            },
            {
              name: "Ibuprofen 200mg",
              dosage: "1 tablet",
              frequency: "2 times daily",
              duration: "5 days",
              instructions: "Take after meals",
            },
          ],
          doctorName: "Dr. Sarah Johnson",
          date: "2024-01-15",
          hospital: "City Hospital",
        })
        setIsScanning(false)
      }, 3000)
    }
  }

  const handleCameraCapture = () => {
    // For mobile devices, this will open the camera
    const input = document.createElement("input")
    input.type = "file"
    input.accept = "image/*"
    input.capture = "environment" // Use rear camera
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        handleFileUpload({ target: { files: [file] } } as any)
      }
    }
    input.click()
  }

  const addToReminders = (medication: any) => {
    // This would integrate with the reminders system
    alert(`Added ${medication.name} to your reminders!`)
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-emerald-50 to-emerald-100">
      <PatientSidebar />

      <div className="flex-1 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Scan Prescription</h1>
            <p className="text-gray-600">Upload or scan your prescription to automatically add medications</p>
          </div>

          {!scannedData ? (
            <Card className="bg-white border-emerald-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    {isScanning ? (
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
                    ) : (
                      <Scan className="w-12 h-12 text-emerald-500" />
                    )}
                  </div>

                  {isScanning ? (
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">Processing Prescription...</h3>
                      <p className="text-gray-600">Our AI is analyzing your prescription</p>
                    </div>
                  ) : (
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-4">Upload Your Prescription</h3>
                      <p className="text-gray-600 mb-6">Take a photo or upload an image of your prescription</p>

                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="prescription-upload" className="sr-only">
                            Upload prescription
                          </Label>
                          <Input
                            id="prescription-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                          <Button
                            onClick={() => document.getElementById("prescription-upload")?.click()}
                            className="bg-emerald-500 hover:bg-emerald-600 text-white mr-4"
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Image
                          </Button>
                          <Button
                            onClick={handleCameraCapture}
                            variant="outline"
                            className="border-emerald-500 text-emerald-600 bg-transparent"
                          >
                            <Camera className="w-4 h-4 mr-2" />
                            Take Photo
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Prescription Info */}
              <Card className="bg-white border-emerald-200">
                <CardHeader>
                  <CardTitle className="flex items-center text-emerald-600">
                    <FileText className="w-6 h-6 mr-2" />
                    Prescription Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Doctor</p>
                      <p className="font-semibold">{scannedData.doctorName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Date</p>
                      <p className="font-semibold">{scannedData.date}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Hospital</p>
                      <p className="font-semibold">{scannedData.hospital}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Medications */}
              <Card className="bg-white border-emerald-200">
                <CardHeader>
                  <CardTitle>Prescribed Medications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {scannedData.medications.map((medication: any, index: number) => (
                      <div key={index} className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-2">{medication.name}</h3>
                            <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                              <div>
                                <span className="font-medium">Dosage:</span> {medication.dosage}
                              </div>
                              <div>
                                <span className="font-medium">Frequency:</span> {medication.frequency}
                              </div>
                              <div>
                                <span className="font-medium">Duration:</span> {medication.duration}
                              </div>
                              <div>
                                <span className="font-medium">Instructions:</span> {medication.instructions}
                              </div>
                            </div>
                          </div>
                          <Button
                            onClick={() => addToReminders(medication)}
                            size="sm"
                            className="bg-emerald-500 hover:bg-emerald-600 text-white"
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            Add to Reminders
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 flex justify-center space-x-4">
                    <Button onClick={() => setScannedData(null)} variant="outline" className="border-gray-300">
                      Scan Another
                    </Button>
                    <Button
                      onClick={() => {
                        scannedData.medications.forEach((med: any) => addToReminders(med))
                        alert("All medications added to reminders!")
                      }}
                      className="bg-emerald-500 hover:bg-emerald-600 text-white"
                    >
                      Add All to Reminders
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
