"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Bot, User, Send, AlertTriangle, Heart, Brain } from "lucide-react"
import { PatientSidebar } from "@/components/patient-sidebar"
import {
  MedicationAdherencePredictor,
  HealthRiskAssessment,
  SymptomAnalyzer,
  DrugInteractionChecker,
} from "@/lib/ml-models"

export default function AIAssistantPage() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: "assistant",
      content: `Hi! I'm your AI Health Assistant powered by advanced machine learning. I can help you with:

🔬 **Medication Adherence Prediction** - Analyze your medication routine
🏥 **Health Risk Assessment** - Evaluate your overall health risks  
🧠 **Symptom Analysis** - Understand your symptoms better
💊 **Drug Interaction Checking** - Check for medication conflicts

What would you like help with today?`,
      timestamp: new Date(),
      analysis: null,
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  // Initialize ML models
  const adherencePredictor = new MedicationAdherencePredictor()
  const riskAssessment = new HealthRiskAssessment()
  const symptomAnalyzer = new SymptomAnalyzer()
  const drugChecker = new DrugInteractionChecker()

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      id: Date.now(),
      type: "user" as const,
      content: inputMessage,
      timestamp: new Date(),
      analysis: null,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsLoading(true)

    // Analyze the message and provide ML-powered response
    setTimeout(() => {
      const aiResponse = generateMLResponse(inputMessage)
      setMessages((prev) => [...prev, aiResponse])
      setIsLoading(false)
    }, 2000)
  }

  const generateMLResponse = (input: string): any => {
    const inputLower = input.toLowerCase()

    // Medication adherence analysis
    if (inputLower.includes("medication") || inputLower.includes("adherence") || inputLower.includes("taking pills")) {
      const patientData = {
        age: 35,
        medicationCount: 3,
        sideEffectsSeverity: 2,
        socialSupportScore: 4,
        previousAdherenceRate: 0.85,
        reminderFrequency: 2,
      }

      const prediction = adherencePredictor.predict(patientData)

      return {
        id: Date.now() + 1,
        type: "assistant" as const,
        content: `Based on my analysis of your medication profile:

**Adherence Probability: ${(prediction.adherenceProbability * 100).toFixed(1)}%**
**Risk Level: ${prediction.riskLevel.toUpperCase()}**

**Recommendations:**
${prediction.recommendations.map((rec) => `• ${rec}`).join("\n")}

This prediction is based on factors like your age, medication complexity, and past adherence patterns.`,
        timestamp: new Date(),
        analysis: {
          type: "adherence",
          data: prediction,
        },
      }
    }

    // Health risk assessment
    if (inputLower.includes("health risk") || inputLower.includes("risk assessment")) {
      const patientData = {
        age: 35,
        bmi: 26.5,
        bloodPressure: { systolic: 130, diastolic: 85 },
        cholesterol: 200,
        smokingStatus: false,
        diabetesHistory: false,
        familyHistory: ["heart_disease"],
      }

      const assessment = riskAssessment.assessRisk(patientData)

      return {
        id: Date.now() + 1,
        type: "assistant" as const,
        content: `**Health Risk Assessment Results:**

**Overall Risk Level: ${assessment.overallRisk.toUpperCase()}**

**Identified Risk Factors:**
${assessment.riskFactors.map((factor) => `⚠️ ${factor}`).join("\n")}

**Recommendations:**
${assessment.recommendations.map((rec) => `✅ ${rec}`).join("\n")}

**Recommended Screening Schedule:**
${assessment.screeningSchedule.map((screen) => `📅 ${screen}`).join("\n")}`,
        timestamp: new Date(),
        analysis: {
          type: "risk_assessment",
          data: assessment,
        },
      }
    }

    // Symptom analysis
    if (
      inputLower.includes("symptom") ||
      inputLower.includes("pain") ||
      inputLower.includes("fever") ||
      inputLower.includes("headache")
    ) {
      const symptoms = []
      if (inputLower.includes("chest pain")) symptoms.push("chest pain")
      if (inputLower.includes("fever")) symptoms.push("fever")
      if (inputLower.includes("headache")) symptoms.push("headache")
      if (inputLower.includes("shortness of breath")) symptoms.push("shortness of breath")

      if (symptoms.length === 0) {
        symptoms.push("headache") // Default for demo
      }

      const analysis = symptomAnalyzer.analyzeSymptoms(symptoms, {})

      return {
        id: Date.now() + 1,
        type: "assistant" as const,
        content: `**Symptom Analysis Results:**

**Urgency Level: ${analysis.urgencyLevel.toUpperCase()}**

**Possible Conditions:**
${analysis.possibleConditions
  .map(
    (condition) =>
      `• ${condition.condition} (${(condition.probability * 100).toFixed(1)}% probability, ${condition.urgency} urgency)`,
  )
  .join("\n")}

**Recommendations:**
${analysis.recommendations.map((rec) => `🏥 ${rec}`).join("\n")}

⚠️ **Disclaimer:** This is an AI analysis and should not replace professional medical advice.`,
        timestamp: new Date(),
        analysis: {
          type: "symptom_analysis",
          data: analysis,
        },
      }
    }

    // Drug interaction check
    if (inputLower.includes("drug interaction") || inputLower.includes("medication interaction")) {
      const medications = ["warfarin", "aspirin"] // Example medications
      const interactions = drugChecker.checkInteractions(medications)

      return {
        id: Date.now() + 1,
        type: "assistant" as const,
        content: `**Drug Interaction Analysis:**

**Interactions Found: ${interactions.hasInteractions ? "YES" : "NO"}**

${
  interactions.hasInteractions
    ? `
**Detected Interactions:**
${interactions.interactions
  .map(
    (interaction) =>
      `⚠️ ${interaction.drug1} + ${interaction.drug2}: ${interaction.description} (${interaction.severity} severity)`,
  )
  .join("\n")}

**Recommendations:**
${interactions.recommendations.map((rec) => `🔔 ${rec}`).join("\n")}
`
    : "No interactions detected with your current medications."
}`,
        timestamp: new Date(),
        analysis: {
          type: "drug_interaction",
          data: interactions,
        },
      }
    }

    // General health advice
    return {
      id: Date.now() + 1,
      type: "assistant" as const,
      content: `I understand you're asking about "${input}". 

I can provide more specific help if you mention:
• **Medication concerns** - for adherence prediction
• **Health risks** - for comprehensive risk assessment  
• **Symptoms** - for AI-powered symptom analysis
• **Drug interactions** - for medication safety checks

What specific aspect of your health would you like me to analyze using my ML capabilities?`,
      timestamp: new Date(),
      analysis: null,
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const getAnalysisIcon = (type: string) => {
    switch (type) {
      case "adherence":
        return <Heart className="w-4 h-4" />
      case "risk_assessment":
        return <AlertTriangle className="w-4 h-4" />
      case "symptom_analysis":
        return <Brain className="w-4 h-4" />
      case "drug_interaction":
        return <Bot className="w-4 h-4" />
      default:
        return <Bot className="w-4 h-4" />
    }
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <PatientSidebar />

      <div className="flex-1 p-6">
        <div className="max-w-4xl mx-auto h-full flex flex-col">
          {/* Header */}
          <Card className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white mb-6">
            <CardContent className="p-6 text-center">
              <Bot className="w-12 h-12 mx-auto mb-4" />
              <h1 className="text-2xl font-bold mb-2">AI Health Assistant</h1>
              <p className="text-blue-100">Powered by Machine Learning & Advanced Analytics</p>
              <div className="flex justify-center space-x-4 mt-4">
                <Badge className="bg-white/20 text-white">
                  <Heart className="w-3 h-3 mr-1" />
                  Adherence Prediction
                </Badge>
                <Badge className="bg-white/20 text-white">
                  <Brain className="w-3 h-3 mr-1" />
                  Symptom Analysis
                </Badge>
                <Badge className="bg-white/20 text-white">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Risk Assessment
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Chat Messages */}
          <Card className="flex-1 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-0 h-full flex flex-col">
              <ScrollArea className="flex-1 p-6">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-4 ${
                          message.type === "user" ? "bg-blue-500 text-white" : "bg-gray-700 text-white"
                        }`}
                      >
                        <div className="flex items-start space-x-2">
                          {message.type === "assistant" && <Bot className="w-5 h-5 mt-1 flex-shrink-0" />}
                          {message.type === "user" && <User className="w-5 h-5 mt-1 flex-shrink-0" />}
                          <div className="flex-1">
                            <p className="whitespace-pre-wrap">{message.content}</p>
                            {message.analysis && (
                              <div className="mt-3 p-2 bg-white/10 rounded border-l-2 border-white/30">
                                <div className="flex items-center text-sm opacity-90 mb-1">
                                  {getAnalysisIcon(message.analysis.type)}
                                  <span className="ml-1">ML Analysis</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-700 text-white rounded-lg p-4 max-w-[80%]">
                        <div className="flex items-center space-x-2">
                          <Bot className="w-5 h-5" />
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                            <div
                              className="w-2 h-2 bg-white rounded-full animate-bounce"
                              style={{ animationDelay: "0.1s" }}
                            ></div>
                            <div
                              className="w-2 h-2 bg-white rounded-full animate-bounce"
                              style={{ animationDelay: "0.2s" }}
                            ></div>
                          </div>
                          <span className="text-sm">Analyzing with ML models...</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="border-t p-4">
                <div className="flex space-x-2">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask about medications, symptoms, health risks..."
                    className="flex-1"
                    disabled={isLoading}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={isLoading || !inputMessage.trim()}
                    className="bg-blue-500 hover:bg-blue-600"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex space-x-2 mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setInputMessage("Analyze my medication adherence")}
                    className="text-xs"
                  >
                    Medication Analysis
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setInputMessage("Check my health risks")}
                    className="text-xs"
                  >
                    Risk Assessment
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setInputMessage("I have a headache and fever")}
                    className="text-xs"
                  >
                    Symptom Check
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
